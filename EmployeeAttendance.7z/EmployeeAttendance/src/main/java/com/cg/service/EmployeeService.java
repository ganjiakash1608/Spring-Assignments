package com.cg.service;

import java.util.List;

import com.cg.entity.Employee;

public interface EmployeeService {

	public Employee addEmployee(Employee e);

	public List<Employee> getEmployeeList();
	
	public Employee updateEmployee(int id,Employee e);
	
	public String deleteEmployee(int id);
	
	public Employee getEmployeeById(int id);
}
