package com.cg.bean;

public class Education {

}
