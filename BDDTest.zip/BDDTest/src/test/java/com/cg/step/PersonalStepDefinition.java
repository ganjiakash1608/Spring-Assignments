package com.cg.step;

public class PersonalStepDefinition {

}
