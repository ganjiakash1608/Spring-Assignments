import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, Validators } from '@angular/forms';
import { LoginServiceService } from "../login-service.service";
import { Employee } from '../model/employeeDetails';

@Component({
  selector: 'app-employee-login',
  templateUrl: './employee-login.component.html',
  styleUrls: ['./employee-login.component.css']
})
export class EmployeeLoginComponent implements OnInit {
  logincheck: Employee[];
  employeeArr:Employee[];
  employee:Employee;
  login: Employee;
  employeecheck: Employee;
  employeeEmailId: any;
  employeePassword: any;

  constructor(private router: Router, private service: LoginServiceService) { 
    this.login = new Employee();
    this.employeeEmailId = this.login.employeeEmailId;
    this.employeePassword = this.login.employeePassword;
  }

  ngOnInit() {
  }
  getEmployee() {

    this.service.getEmployee().subscribe(res => {

      this.logincheck = res;
      this.employeecheck = this.logincheck[0];
      console.log(this.login.employeeEmailId)
      console.log(this.login.employeePassword)
      console.log(this.employeecheck.employeeEmailId)
      console.log(this.employeecheck.employeePassword)
      for(const p of this.employeeArr)
      {
        console.log(this.login.employeeEmailId)
      if (this.login.employeeEmailId === p.employeeEmailId && this.login.employeePassword ===p.employeePassword) {
        //console.log(this.login.employeeEmailId)
       // console.log(this.login.employeePassword)
       // console.log(this.employeecheck.employeeEmailId)
       // console.log(this.employeecheck.employeePassword)
        {this.router.navigate(['/employee']);
      }
      }
      
     
    }
    })



  }
}
