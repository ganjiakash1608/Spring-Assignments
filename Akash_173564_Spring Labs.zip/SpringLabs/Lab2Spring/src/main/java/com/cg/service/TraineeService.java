package com.cg.service;

import com.cg.entity.Trainee;

public interface TraineeService {
	
	public Trainee addTrainee(Trainee trainee);
	
	public Trainee getTrainee(int id);
	
	public String deleteTrainee(Trainee t1);
	
	Iterable<Trainee> getAll();
	
	public Trainee updateTrainee(Trainee t, int id);
	
}
