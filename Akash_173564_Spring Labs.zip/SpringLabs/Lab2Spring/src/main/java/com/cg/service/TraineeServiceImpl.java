package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.TraineeDao;
import com.cg.entity.Trainee;

@Service
@Transactional
public class TraineeServiceImpl implements TraineeService {
	
	@Autowired
	TraineeDao dao;
	
	public Trainee addTrainee(Trainee trainee) {
		return dao.save(trainee);
	}
	
	@Override
	public Trainee getTrainee(int id) {
		return dao.findById(id).get();
	}
	
	@Override
	public String deleteTrainee(Trainee trainee) {
		dao.delete(trainee);
		return "Delete Successfully";
	}
	
	@Override
	public Iterable<Trainee> getAll() {
		return dao.findAll();
	}

	@Override
	public Trainee updateTrainee(Trainee trainee, int id) {
		trainee.setId(id);
		dao.save(trainee);
		return trainee;
	}
}
