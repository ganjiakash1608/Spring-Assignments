package com.cg.ctrl;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entity.Login;
import com.cg.entity.Trainee;
import com.cg.service.TraineeService;

@Controller
public class TraineeController {

	@Autowired
	TraineeService service;

	ArrayList<String> locationList;
	ArrayList<String> domain;
	Trainee trainee;

	@RequestMapping("/")
	public String home(Model model) {
		model.addAttribute("login", new Login());
		return "login";
	}

	@RequestMapping(value = "checkLogin")
	public String checkLogin(Login login, Model model) {
		model.addAttribute("Login", new Login());
		if (login.getUserName().equals("training") && login.getPassword().equals("java")) {
			return "loginSuccess";
		} else
			return "login";
	}

	@RequestMapping(value = "/addTrainee")
	public String addTrainee(Model model) {
		locationList = new ArrayList<>();
		domain = new ArrayList<>();

		model.addAttribute("trainee", new Trainee());
		locationList.add("Pune");
		locationList.add("Mumbai");
		locationList.add("Hyderabad");
		locationList.add("Bangalore");

		domain.add("Java");
		domain.add("Python");
		domain.add("Hibernate");
		domain.add("Struts");
		domain.add("Spring");

		model.addAttribute("locationList", locationList);
		model.addAttribute("domain", domain);
		return "addTrainee";

	}

	@RequestMapping(value = "/save")
	public String addtrn(@ModelAttribute("trainee") @Valid Trainee trn, BindingResult result, Model model) {
		if (result.hasErrors()) {
			model.addAttribute("error", "Please add proper details");
			model.addAttribute("locationList", locationList);
			model.addAttribute("domain", domain);
			return "addTrainee";
		} else {
			service.addTrainee(trn);
			model.addAttribute("result", "Trainee Added");
			return "loginSuccess";
		}
	}

	@RequestMapping(value = "/delete")
	public String deletepage(Model model) {
		return "delete";
	}

	@RequestMapping("/search")
	public String retrieveTodelete(Model model, @RequestParam("id") int id) {
		trainee = service.getTrainee(id);
		model.addAttribute(trainee);
		return "delete";
	}

	@RequestMapping("/deleteTrainee")
	public String deleteTrainee(Model model, Trainee trainee) {
		service.deleteTrainee(trainee);
		return "loginSuccess";
	}

	@RequestMapping(value = "/retrieve")
	public String retrieveDetails(Model model) {
		return "retrieve";
	}

	@RequestMapping("/retrieveSingle")
	public String retrieveSingle(Model model, @RequestParam("traineeId") int traineeId) {
		trainee = service.getTrainee(traineeId);
		model.addAttribute(trainee);
		return "retrieve";
	}

	@RequestMapping(value = "/retrieveall")
	public String retrieveAll(Model model) {
		Iterable<Trainee> traineeList = service.getAll();
		model.addAttribute("trainee", traineeList);
		return "retrieveAll";
	}
	
	@RequestMapping(value = "/goToHome")
	public String goToHome(Model model) {
		return "loginSuccess";
	}

}
