package com.cg.restController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.entity.Product;
import com.cg.repo.ProductRepo;

@Controller
public class ProductController {

	@Autowired
	private ProductRepo repo;

	// Exception Handle for Exceptions
	@ExceptionHandler({ java.sql.SQLIntegrityConstraintViolationException.class,
			org.springframework.web.util.NestedServletException.class,
			org.springframework.orm.jpa.JpaSystemException.class, javax.persistence.PersistenceException.class,
			org.hibernate.exception.ConstraintViolationException.class })

	// initial root
	@GetMapping("/")
	public ModelAndView product(Model model) {
		return new ModelAndView("AddProduct", "productdetails", new Product());
	}

	// saving new product with data
	@PostMapping("savenewproduct")
	public ModelAndView saveProduct(@ModelAttribute("productdata") Product prod, Model model) {
		repo.addProduct(prod);
		return new ModelAndView("savedproduct", "productdata", new Product());

	}

	// for showing all products with respective data
	@GetMapping("addnewproduct")
	public ModelAndView searchAllproduct(Model model) {

		return new ModelAndView("saveproduct", "productdata", new Product());
	}

	@GetMapping("/showproducts")
	public ModelAndView searchAllProducts(Model model) {

		Iterable<Product> productList = repo.getAllProducts();

		return new ModelAndView("showproducts", "productList", productList);
	}

	// Displaying Error while no data found after searching
	public ModelAndView displayErrors() {
		return new ModelAndView("nodata");
	}

}
