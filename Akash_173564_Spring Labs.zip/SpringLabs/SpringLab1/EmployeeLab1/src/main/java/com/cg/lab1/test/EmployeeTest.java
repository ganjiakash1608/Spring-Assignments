package com.cg.lab1.test;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.lab1.bean.Employee;

public class EmployeeTest {
	
	@Test
	public void test() {
		ApplicationContext emp=new ClassPathXmlApplicationContext("employee.xml");
		Employee e=emp.getBean(Employee.class);
		System.out.println(e.getEmployeeId());
		System.out.println(e.getEmployeeName());
		System.out.println(e.getSalary());
		System.out.println(e.getBusinessUnit());
		System.out.println(e.getAge());
		assertNotNull(e);
	}

}
