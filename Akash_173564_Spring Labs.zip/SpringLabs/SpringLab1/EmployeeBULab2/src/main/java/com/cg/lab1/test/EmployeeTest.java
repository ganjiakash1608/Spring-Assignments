package com.cg.lab1.test;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.lab1.bean.Employee;

public class EmployeeTest {
	
	@Test
	public void test() {
		ApplicationContext employee=new ClassPathXmlApplicationContext("employee.xml");
		Employee e=employee.getBean(Employee.class);
		System.out.println(e);
		assertNotNull(e);
	}

}
