package com.cg.bean;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.dao.DaoI;
import com.cg.dao.DaoImpl;

public class Client {
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Employee Id to search:");


		int id = scan.nextInt();
		
		DaoI dao = new DaoImpl();
		dao.addAll();
		
		//find employee by id
		Employee employee =dao.findEmployee(id);
		System.out.println(employee);
	
	}
}
